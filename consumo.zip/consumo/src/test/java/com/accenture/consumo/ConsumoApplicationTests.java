package com.accenture.consumo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumoApplicationTests {

	@Test
	void contextLoads() {
	}

}
